# Bhai ab yeh bhi mein hi karu tu kyaa kar rha hai fir??
## Andhaa hai kya? Same hi hai yeh aur 10th vaala jaa jaake dekhle problem statement